Q3 changes only the complete future-weather tensor and evaluates masked loss
over the complete 20-step window. `protocol.json` freezes cohort construction,
matching, intervention arms, and uncertainty units. `climatology_summary.json`
records the training-derived thresholds and counts. Pair paths in
`manifests/q3_pairs.json` are relative to the OOD-t split root.
