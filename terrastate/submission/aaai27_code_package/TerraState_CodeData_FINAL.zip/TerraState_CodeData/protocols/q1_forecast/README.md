Q1 applies `manifests/q1_files.json` to the public GreenEarthNet root and
reports land-cover-balanced OOD-t forecast metrics. The manifest contains
1,904 minicubes and paths prefixed by `ood-t_chopped/`.
