Q2 compares the full model with state removal and an identity-transition
control on the same split. The public evaluator scans one supplied split root
per invocation; run validation and OOD-t separately. `manifests/q2_splits.json`
records the submitted split and paired-unit counts.
