# TerraState code and protocol package

This anonymous package provides the TerraState model and dataset interfaces,
the training entry point, Q1--Q3 evaluators, frozen protocol metadata, and the
reported reference summaries. Public GreenEarthNet data and model weights are
not included. Training additionally requires the initial checkpoint, teacher
checkpoint, and future-state target cache supplied by the user.

- `models/`, `data/`, `train/`, and `eval/`: implemented interfaces and entry points.
- `configs/terrastate.yaml`: architecture, preprocessing, and the complete
  40-epoch / 14,880-update training configuration.
- `manifests/` and `protocols/`: frozen split and Q1--Q3 protocol metadata.
- `results/`: submitted reference summaries; do not overwrite these files.

Install the small runtime dependency set:

```bash
python -m pip install -r requirements.txt
mkdir -p outputs
```

`GREENEARTHNET_ROOT` is the public dataset root containing split directories
such as `val_chopped/` and `ood-t_chopped/`. A compatible selected model is
denoted by `CHECKPOINT`.

Training interface:

```bash
python train/train_terrastate.py \
  --config configs/terrastate.yaml \
  --data-root GREENEARTHNET_TRAIN_ROOT \
  --initial-checkpoint INITIAL_CHECKPOINT \
  --teacher-checkpoint TEACHER_CHECKPOINT \
  --future-state-cache FUTURE_STATE_CACHE \
  --output-dir OUTPUT_DIR
```

Q1 uses the GreenEarthNet root because the frozen manifest paths include the
`ood-t_chopped/` prefix:

```bash
python eval/evaluate_forecast.py \
  --config configs/terrastate.yaml \
  --data-root GREENEARTHNET_ROOT \
  --manifest manifests/q1_files.json \
  --checkpoint CHECKPOINT \
  --output outputs/q1_metrics.json
```

Q2 scans one declared split root per invocation. Run validation and OOD-t
separately:

```bash
python eval/evaluate_state_load_bearing.py \
  --config configs/terrastate.yaml \
  --data-root GREENEARTHNET_ROOT/val_chopped \
  --checkpoint CHECKPOINT \
  --output outputs/q2_validation.json

python eval/evaluate_state_load_bearing.py \
  --config configs/terrastate.yaml \
  --data-root GREENEARTHNET_ROOT/ood-t_chopped \
  --checkpoint CHECKPOINT \
  --output outputs/q2_oodt.json
```

Q3 pair paths are relative to the OOD-t split root:

```bash
python eval/evaluate_weather_response.py \
  --config configs/terrastate.yaml \
  --data-root GREENEARTHNET_ROOT/ood-t_chopped \
  --manifest manifests/q3_pairs.json \
  --checkpoint CHECKPOINT \
  --output outputs/q3_metrics.json
```

The evaluator outputs are compact metric summaries. The frozen JSON files in
`results/` record the values used in the submission. See `LICENSES.md` for
third-party notices.
